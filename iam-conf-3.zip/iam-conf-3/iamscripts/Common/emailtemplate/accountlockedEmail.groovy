emailStr = "Dear " + user.firstName + " " + user.lastName + ": \n\n" +
 	"Your account has been locked due to numerous failed authenication attempts. \n\n" + 
 	"\n\n" +
 	"If this activity was not caused by you, please contact the security office at support@openiam.org"
 	
output=emailStr