emailStr = "Dear " + user.firstName + " " + user.lastName + ": \n\n" +
 	"Your account has been terminated based on the account expiration date. \n\n" 

 	
output=emailStr