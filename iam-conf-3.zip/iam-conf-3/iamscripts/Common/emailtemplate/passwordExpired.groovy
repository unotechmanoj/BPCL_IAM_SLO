

emailStr = "Dear " + user.firstName + " " + user.lastName + ": \n\n" +
 	"Your password has expired. \n\n\n" + 
 	"Please log into the selfservice application to change your password and re-activate your account.\n" +
 	"http://localhost:8080/selfservice"
 	
output=emailStr