emailStr = "Dear " + user.firstName + " " + user.lastName + ": \n\n" +
 	"Your account status has been changed due to inactivity. \n\n" + 
 	"Please contact the security office to have your account reactivated."

 	
output=emailStr