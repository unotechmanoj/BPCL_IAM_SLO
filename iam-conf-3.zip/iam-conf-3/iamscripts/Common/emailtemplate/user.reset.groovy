def String targetURL = req.getNotificationParam("baseUrl").valueObj
def String token = req.getNotificationParam("token").valueObj
//def String lastName = req.getNotificationParam("token").valueObj
//def String firstName = req.getNotificationParam("token").valueObj

def found = user.principalList.find {login -> login.managedSysId == "0"}
String login = found.login

emailStr = "Dear " + user.firstName + " " + user.lastName + ": \n\n" +
        "A  request has been created to reset your account password. Please click on the URL below to reset your account. \n" +
        "After your password has been successfully reset, you will be able login with the new password. \n\n" +
        "\n\n" +
		"Your login is " + login + "\n\n" +
        targetURL + "?token="  +  token + " \n\n" +
        "If you did not create this request, then please contact your security administrator. \n"

output=emailStr
