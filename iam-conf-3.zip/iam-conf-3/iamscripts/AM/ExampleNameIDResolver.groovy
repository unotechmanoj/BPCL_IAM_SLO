import org.openiam.ui.idp.saml.groovy.DefaultNameIDResolver;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.openiam.base.ws.MatchType;
import org.openiam.base.ws.SearchParam;
import org.openiam.idm.searchbeans.EmailSearchBean;
import org.openiam.idm.srvc.auth.dto.Login;
import org.openiam.idm.srvc.auth.ws.LoginDataWebService;
import org.openiam.idm.srvc.auth.ws.LoginListResponse;
import org.openiam.idm.srvc.continfo.dto.EmailAddress;
import org.openiam.idm.srvc.user.ws.UserDataWebService;
import org.openiam.ui.util.SpringContextProvider;
import org.opensaml.saml2.core.NameID;
import org.opensaml.saml2.core.NameIDType;
import org.opensaml.saml2.core.Response;
import org.opensaml.xml.security.SecurityException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class ExampleNameIDResolver extends DefaultNameIDResolver {

	public ExampleNameIDResolver() {
		super();
	}

    @Override
    public String getPrincipal(final String managedSysId, final boolean justInTimeAuthEnabled) throws SecurityException {
    	System.out.println("Custom Get Principal!!!");
    	return super.getPrincipal(managedSysId, justInTimeAuthEnabled);
    }
}