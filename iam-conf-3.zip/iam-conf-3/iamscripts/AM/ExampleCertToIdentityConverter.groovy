import org.openiam.am.cert.groovy.DefaultCertToIdentityConverter;
import org.openiam.exception.BasicDataServiceException;
import org.openiam.idm.srvc.auth.dto.Login;

class ExampleCertToIdentityConverter extends DefaultCertToIdentityConverter {

    public ExampleCertToIdentityConverter() {
        super();
    }
    
    public Login resolve() throws BasicDataServiceException {
        return null;
    }
}
