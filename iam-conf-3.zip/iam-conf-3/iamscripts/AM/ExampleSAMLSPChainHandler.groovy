import org.openiam.ui.idp.saml.groovy.AbsractSAMLSPChainHandler
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.openiam.ui.idp.saml.exception.CustomSAMLException;
import org.openiam.ui.util.SpringContextProvider;
import org.opensaml.saml2.core.Response;

public class ExampleSAMLSPChainHandler extends AbsractSAMLSPChainHandler {

    @Override
    public void process(final Response currentSAMLResponse) throws CustomSAMLException {
    	System.out.println(this);
    	System.out.println("Called process - you code here");
    }
}