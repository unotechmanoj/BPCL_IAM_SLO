import org.openiam.ui.idp.saml.groovy.DefaultServiceProviderRelayStateGenerator;

class ExampleServiceProviderRelayStateGenerator extends DefaultServiceProviderRelayStateGenerator {

    public ExampleServiceProviderRelayStateGenerator() {
        super();
    }
    
    @Override
    public String getRelayState() {
        return super.getRelayState();
    }
}