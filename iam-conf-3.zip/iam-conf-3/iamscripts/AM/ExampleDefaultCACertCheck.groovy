import org.bouncycastle.cert.X509CRLHolder;
import org.openiam.am.cert.groovy.DefaultCACertCheck;
import org.openiam.base.ws.ResponseCode;
import org.openiam.exception.BasicDataServiceException;

import java.util.ArrayList;
import java.util.List;

class ExampleCACertCheck extends DefaultCACertCheck {

	public ExampleCACertCheck() {
		super();
	}

	public Boolean resolve() throws BasicDataServiceException {
		if (caCert != null) {
			try {
				caCert.checkValidity();
			} catch (Exception ex) {
				throw new BasicDataServiceException(ResponseCode.CERT_CA_INVALID, ex.getMessage());
			}
			if (clientCert != null) {
				try {
					clientCert.checkValidity();
				} catch (Exception ex) {
					throw new BasicDataServiceException(ResponseCode.CERT_CLIENT_INVALID, ex.getMessage());
				}
				try {
					clientCert.verify(caCert.getPublicKey());
				} catch (Exception ex) {
					throw new BasicDataServiceException(ResponseCode.CERT_INVALID_VERIFY_WITH_CA, ex.getMessage());
				}

				try {
					certManager.verifyCertificateNotRevoked(caCert, clientCert);
				} catch (Exception ex) {
					if (StringUtils.isBlank(crlPath)) {
						List<X509CRLHolder> crlList = new ArrayList<X509CRLHolder>();
						// "file://crl.der"    "https://lnx1.openiamdemo.com/crl"
						crlList.add(certManager.downloadCRL(crlPath));
						certManager.verifyCertificateNotRevoked(crlList, caCert, clientCert);
					}
				}

			}
		}
		return true;
	}
}

