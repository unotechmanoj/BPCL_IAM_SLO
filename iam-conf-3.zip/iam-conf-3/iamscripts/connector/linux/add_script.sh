#!/bin/bash

useradd -N  $1
echo $1
