#!/bin/bash

echo "Inputs for SHELL: login=" "$1" "groups=" "$2" "password=" "$3" 
if [[ ! -z "$3" ]] && [[ ! -z "$2" ]]
then
    useradd -N  "$1" -G "$2" 
echo -e ""$3"\n"$3"" | passwd "$1"
echo ">>>>>>" useradd -N  "$1" -G "$2" 
fi

if [[ ! -z "$3" ]] && [[  -z "$2" ]]
then
 useradd -N  "$1"
echo -e ""$3"\n"$3"" | passwd "$1"
echo ">>>>>>" useradd -N  "$1" 
fi

if [[ -z "$3" ]]
then
    groupadd "$1"
echo ">>>>>>"   groupadd "$1"
fi


