#!/bin/bash

userdel $1
echo $1
