// password variable is bound into groovy through the integration framework
output=password