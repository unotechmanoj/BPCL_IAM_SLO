output = lg.login
