if (user.firstName != null && user.firstName.length() > 0) {

  output=user.firstName 
}else {
  output = null
}