import org.openiam.idm.srvc.auth.dto.Login
import org.openiam.idm.srvc.user.dto.User
import org.openiam.idm.srvc.user.ws.UserDataWebService

/**
 * Manager.groovy
 * Returns the name of a person immediate supervisor. Return the DN so that it works with AD
 */

def userWS = context.getBean("userWS") as UserDataWebService

output = null

// user is passed into the script as a bind variable in the service that calls this script

def superiors = userWS.getSuperiors(user.id, 0, Integer.MAX_VALUE)
println("****** superiors:" + superiors);
if (superiors) {
	println("***** superiors:" + superiors);
	println("***** superiors.size():" + superiors.size());
    User supervisor = superiors.get(0)
println("***==* User - supervisor:" + supervisor);
println("***==* User - supervisor.id:" + supervisor.id);
println("***==* supervisor.getPrincipalList():" + supervisor.getPrincipalList());
	for (Login ll : supervisor.getPrincipalList()) {
		println("ll:" + ll);
	}
println("*+--+** l:" + supervisor.principalList.size());
    def l = supervisor.principalList?.find {Login l-> l.managedSysId == managedSysId}
println("*++** l:" + l);
println("*** managedSysId:" + managedSysId);
println("*** l?.login:" + l?.login);
    output = l?.login
}


