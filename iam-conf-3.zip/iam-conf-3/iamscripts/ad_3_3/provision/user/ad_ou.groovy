// for Powershell-AD connector use full path: output = 'ou=test' + ',' + matchParam.baseDn
import org.openiam.idm.groovy.helper.ServiceHelper;
import java.util.List;
import org.openiam.idm.srvc.org.dto.Organization;
import org.openiam.idm.srvc.org.dto.OrganizationAttribute;
import org.openiam.idm.srvc.org.service.OrganizationDataService;

def orgService = ServiceHelper.orgService();
output = null;
def List<Organization> orgList = orgService.getOrganizationsForUserByTypeLocalized(user.id, null, "ORGANIZATION", null);
if(orgList != null && orgList.size() > 0) {
	println("*** orgList.get(0).id : " + orgList.get(0).id);
   	Organization org = orgService.getOrganizationLocalized(orgList.get(0).id, null, null);
	println("*** org : " + org);
	
	if (org?.attributes) {
		for(OrganizationAttribute atr : org?.attributes) {
			println("Attr : " + atr.getName());
			if (atr.getName() == "AD_PATH") {
				output=atr.getValue();
			}
		} 
	}
}
println("OU=" + output);

