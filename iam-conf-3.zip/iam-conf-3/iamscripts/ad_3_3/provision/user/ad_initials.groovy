


if (user.middleInit != null && user.middleInit.length() > 0 ) {
  output =user.middleInit 
}else {
	output=null
}

