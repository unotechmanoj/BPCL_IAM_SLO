iam-configuration
=================

OpenIAM Groovy Scripts