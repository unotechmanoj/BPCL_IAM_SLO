import org.apache.commons.collections.CollectionUtils
import org.apache.commons.lang.StringUtils
import org.codehaus.jackson.map.ObjectMapper
import org.openiam.idm.searchbeans.AuditLogSearchBean
import org.openiam.idm.srvc.audit.dto.IdmAuditLog
import org.openiam.idm.srvc.audit.ws.IdmAuditLogWebDataService
import org.openiam.idm.srvc.file.ws.FileWebService

import java.text.SimpleDateFormat

println("archieve logs task [==== ");

IdmAuditLogWebDataService auditService = context.getBean("auditWS");
FileWebService fileWebService = context.getBean("fileWebService");

String numOfMonthes = param1 ? param1 : "0";
int numOfMonthesInt = 0;
int pageSize = 500;

try {
    numOfMonthesInt = Integer.parseInt(numOfMonthes);
} catch (Exception e) {
    println(e);
    output = 0;
}
String deleteAfterArchieve = param2 ? param2.toLowerCase() : "off";

println("archieve logs task [==== deleteAfterArchieve:${deleteAfterArchieve}");
println("archieve logs task [==== numOfMonthes:${numOfMonthes}");

boolean isDelete = false
if ("on".equalsIgnoreCase(deleteAfterArchieve) || "y".equalsIgnoreCase(deleteAfterArchieve)
        || "true".equalsIgnoreCase(deleteAfterArchieve) || "yes".equalsIgnoreCase(deleteAfterArchieve)) {
    isDelete = true;
}

println("archieve logs task [==== isDelete:${isDelete}");

Calendar cal = Calendar.getInstance();
if (StringUtils.isNotBlank(numOfMonthes)) {
    cal.add(Calendar.MONTH, -1 * numOfMonthesInt);
}

println("archieve logs task [==== processing all older than:${cal.getTime()}");

AuditLogSearchBean auditLogSearchBean = new AuditLogSearchBean();
auditLogSearchBean.to = cal.getTime();
auditLogSearchBean.deepCopy = true;

int count = auditService.count(auditLogSearchBean);
println("archieve logs task [==== count:${count}");
List<IdmAuditLog> auditLogs = new ArrayList<>();

List<String> ids= auditService.getIds(auditLogSearchBean,-1,-1);



if (CollectionUtils.isEmpty(ids)) {
    println("archieve logs task [==== no records");
    output = 1
}

SimpleDateFormat sdf = new SimpleDateFormat("dd_MM_yyyy");
ObjectMapper mapper = new ObjectMapper();
int countPage=0;
int part=1;
for (String id:ids){
    auditLogs.add(auditService.getLogRecord(id));
    countPage++;
    if (countPage==pageSize){
        String fileName = "AUDIT_LOG_BEFORE_${sdf.format(cal.getTime())}_DELETED_${deleteAfterArchieve}_part_${part}.json"
        String result = mapper.writeValueAsString(auditLogs);
        fileWebService.saveFile(fileName, result);
        println("archieve logs task [==== saved to ${fileName}");
        countPage=0;
        part++;
        auditLogs = new ArrayList<>();
    }
}

if (CollectionUtils.isNotEmpty(auditLogs)){
    String fileName = "AUDIT_LOG_BEFORE_${sdf.format(cal.getTime())}_DELETED_${deleteAfterArchieve}_part_${part}.json"
    String result = mapper.writeValueAsString(auditLogs);
    fileWebService.saveFile(fileName, result);
    println("archieve logs task [==== saved to ${fileName}");
}


if (isDelete) {
    auditService.deleteOlderThan(cal.getTime());
    println("archieve logs task [==== Deleted from DB");
}

output = 1
