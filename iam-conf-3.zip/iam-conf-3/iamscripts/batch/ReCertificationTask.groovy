import org.openiam.base.SysConfiguration
import org.openiam.idm.srvc.auth.ws.LoginDataWebService
import org.openiam.idm.srvc.auth.ws.LoginResponse
import org.openiam.idm.srvc.user.service.SupervisorDAO;
import org.apache.commons.collections.CollectionUtils;
import org.openiam.base.ws.ResponseStatus;
import org.openiam.bpm.activiti.ActivitiService;
import org.openiam.base.ws.Response;
import org.openiam.bpm.request.GenericWorkflowRequest;
import org.openiam.bpm.util.ActivitiConstants;
import org.openiam.bpm.util.ActivitiRequestType;
import org.openiam.idm.srvc.user.dto.User;
import org.openiam.idm.srvc.user.service.SupervisorDAO;
import org.openiam.idm.srvc.user.ws.UserDataWebService;
import org.openiam.idm.srvc.user.dto.UserStatusEnum;
import org.openiam.idm.srvc.mngsys.ws.ManagedSystemWebService;
import org.openiam.idm.searchbeans.ManagedSysSearchBean;
import org.openiam.idm.srvc.mngsys.dto.ManagedSysDto;
import org.openiam.authmanager.service.AuthorizationManagerService;
println("=============== ReCertificationTask.groovy called. ==========================")


def supervisorDAO = context.getBean("supervisorDAO") as SupervisorDAO;
def userService = context.getBean("userWS") as UserDataWebService;
def activitiService = context.getBean("activitiBPMService") as ActivitiService;
def loginService = context.getBean("loginWS") as LoginDataWebService;
def sysConfiguration = context.getBean("sysConfiguration") as SysConfiguration;
def mngSysService = context.getBean("managedSysService") as ManagedSystemWebService;
def authManagerService = context.getBean("authorizationManagerService") as AuthorizationManagerService;

List<String> resourceIds = new ArrayList<>();
if(param4!=null && param4.trim().length()>0) {
    println(String.format("===================== param4:%s",param4));
    String[] managedSysNames = param4?.split(",");
    for(String name:managedSysNames) {
        println(String.format("===================== Getting resourceid for managedSys :%s",name));
        ManagedSysSearchBean msb = new ManagedSysSearchBean();
        msb.setName(name);

        List<ManagedSysDto> managedSysDtoList = mngSysService.getManagedSystems(msb,Integer.MAX_VALUE,0);
        if(managedSysDtoList!=null){
            for(ManagedSysDto dto: managedSysDtoList){
                if(dto.getResourceId()!=null) {
                    resourceIds.add(dto.getResourceId());
                    println(String.format("===================== resourceid for managedSys '%s' found",name));
                }
            }
        }
    }
}

Set<String> employeeIds = new HashSet<>();
if(param3!=null && param3.trim().length()>0) {
    println(String.format("===================== param3:%s",param3));
    String[] userLogins = param3?.split(",");
    for(String principal:userLogins) {
        println(String.format("===================== Getting userId for login :%s",principal));
        LoginResponse response = loginService.getLoginByManagedSys(principal,sysConfiguration.getDefaultManagedSysId());
        if(response.isSuccess()){
            println(String.format("===================== userId for login '%s' found",principal));
            employeeIds.add(response.getPrincipal().getUserId());
        }
    }
}

if(CollectionUtils.isEmpty(employeeIds)) {
    employeeIds = supervisorDAO.getUniqueEmployeeIds();
}


if(CollectionUtils.isNotEmpty(employeeIds)) {
    println(String.format("===================== Found employee. Size:%d",employeeIds.size()));

    for(final String employeeId : employeeIds) {
	
        final User user = userService.getUserWithDependent(employeeId,param1,false);
        println(String.format("===================== Employee[id=%s,fName=%s, sName=%s, status=%s]",user.getId(), user.getFirstName(),user.getLastName(), user.getStatus()));
        if(!UserStatusEnum.ACTIVE.equals(user.getStatus()) && !UserStatusEnum.PENDING_INITIAL_LOGIN.equals(user.getStatus())){
            println("==================== Skiping.....");
            continue;
        }

	if(CollectionUtils.isNotEmpty(resourceIds)){
		boolean isEntitle = false;
		for(final String resId : resourceIds) {
			if(authManagerService.isEntitled(employeeId, resId)){
				isEntitle=true;
				break;
			}	
		}
		println(String.format("===================== Employee[id=%s] is entitle to provided managed_sys? : "+isEntitle,user.getId());
              	if(!isEntitle){
			println(String.format("===================== Skip attestation for Employee[id=%s] because he is not entitle to provided managed_sys",user.getId());
			continue;				
		}
        }

	final List<User> supervisords = userService.getSuperiors(employeeId, 0, Integer.MAX_VALUE);
        final Set<String> supervisorIds = new HashSet<String>();
        if(CollectionUtils.isEmpty(supervisords)) {
            println(String.format("Employee %s has no supervisor", employeeId));
            continue;
        }

	for(final User supevisor : supervisords) {
            if(supevisor != null && supevisor.getId() != null) {
                println(String.format("===================== MANAGER[id=%s,fName=%s, sName=%s, status=%s]",supevisor.getId(), supevisor.getFirstName(),supevisor.getLastName(), supevisor.getStatus()));
                if(!UserStatusEnum.ACTIVE.equals(supevisor.getStatus()) &&  !UserStatusEnum.PENDING_INITIAL_LOGIN.equals(supevisor.getStatus())){
                    continue;
                }
                supervisorIds.add(supevisor.getId());
            }
        }

	if(CollectionUtils.isNotEmpty(supervisorIds)) {

            final String taskName = String.format("Re-Certification Request for %s", user.getDisplayName());

            println(String.format("================ Sending Recertification task for %s", user.getDisplayName()));

            final GenericWorkflowRequest request = new GenericWorkflowRequest();
            request.setActivitiRequestType(ActivitiRequestType.ATTESTATION.getKey());
            request.setDescription(taskName);
            request.setName(taskName);
            request.setCustomApproverIds(supervisorIds);
            request.addParameter(ActivitiConstants.EMPLOYEE_ID.getName(), employeeId);
            request.addParameter(ActivitiConstants.ATTESTATION_URL.getName(), param2);
            if(resourceIds!=null && resourceIds.size()>0){
                request.addParameter(ActivitiConstants.ATTESTATION_MANAGED_SYS_RESOURCES.getName(), resourceIds);
            }
            request.setRequestorUserId(param1);
            request.setDeletable(false);
            final Response response = activitiService.initiateWorkflow(request);
            if(!ResponseStatus.SUCCESS.equals(response.getStatus())) {
                println(String.format("Could not initialize re-certification task for user %s.  Reason: %s", employeeId, response.getErrorCode()));
            }
	}
    }
}

println("=================== ReCertification.groovy ended");

output=0

