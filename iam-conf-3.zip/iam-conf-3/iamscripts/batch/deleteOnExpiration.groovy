package org.openiam.connector

import org.openiam.base.AttributeOperationEnum
import org.openiam.idm.srvc.synch.dto.Attribute
import org.openiam.idm.srvc.user.dto.UserAttribute
import org.openiam.idm.srvc.user.dto.UserStatusEnum
import org.openiam.idm.srvc.user.ws.UserDataWebService
import org.openiam.provision.dto.ProvisionUser
import org.openiam.provision.service.ProvisionService

import java.text.SimpleDateFormat


System.out.println("terminateOnExpiration.groovy")

def userService = context.getBean("userWS") as UserDataWebService
def provision = context.getBean("defaultProvision") as ProvisionService

def cal = Calendar.getInstance()
def userList = userService.getUserByLastDate(cal.getTime())

println("Userlist = " + userList)

if (userList) {
    for (user in userList) {
        println("User status=" + user.status)
        println("User id=" + user.id)
        if (UserStatusEnum.PENDING_DEACTIVATION.equals(user.getStatus())) {
            ProvisionUser provisionUser = new ProvisionUser(user);
            provisionUser.setStatus(UserStatusEnum.DELETED);
            provision.modifyUser(provisionUser);
            provision.deleteByUserId(user.id, UserStatusEnum.DELETED, null);
        } else if (UserStatusEnum.PENDING_DELETE.equals(user.getStatus())) {
            ProvisionUser pUser = new ProvisionUser(user);
            provision.deleteByUserId(user.id, UserStatusEnum.REMOVE, null);
        }
    }
}
output = 0


