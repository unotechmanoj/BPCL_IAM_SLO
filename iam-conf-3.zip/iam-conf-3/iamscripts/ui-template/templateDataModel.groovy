
import org.openiam.idm.srvc.meta.service.AbstractTemplateGlobalDataModel;

class CustomTemplateDataModel extends AbstractTemplateGlobalDataModel{

    @Override
    Map getDataModel(String requesterId) {
        return null;
    }
}