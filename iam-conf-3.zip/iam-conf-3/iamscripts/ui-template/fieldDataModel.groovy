import org.openiam.idm.srvc.meta.dto.PageElementValidValue;
import org.openiam.idm.srvc.meta.service.AbstractFieldDataModel;
import java.util.ArrayList;
import java.util.List;

class CustomFieldDataModel extends AbstractFieldDataModel{

    @Override
    public String getDefaultValue(String requesterId) {
        return null;
    }

    @Override
    public List<PageElementValidValue> getDataModel(String requesterId) {
        return null;
    }
}