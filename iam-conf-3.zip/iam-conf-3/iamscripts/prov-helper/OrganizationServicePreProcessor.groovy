import org.openiam.idm.srvc.org.service.AbstractOrganizationServicePrePostProcessor

public class OrganizationServicePreProcessor extends AbstractOrganizationServicePrePostProcessor {

}