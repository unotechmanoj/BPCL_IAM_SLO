import org.openiam.provision.service.AbstractResourceOrderProcessor

public class ProvisionServiceResourceOrderProcessor extends AbstractResourceOrderProcessor {
}