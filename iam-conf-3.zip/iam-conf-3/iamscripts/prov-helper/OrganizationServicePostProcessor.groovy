import org.openiam.idm.srvc.org.service.AbstractOrganizationServicePrePostProcessor

public class OrganizationServicePostProcessor extends AbstractOrganizationServicePrePostProcessor {

}