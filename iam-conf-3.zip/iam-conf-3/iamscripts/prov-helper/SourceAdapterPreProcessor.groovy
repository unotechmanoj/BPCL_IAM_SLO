import org.openiam.provision.dto.srcadapter.SourceAdapterAttributeRequest
import org.openiam.provision.dto.srcadapter.SourceAdapterOrganizationRequest
import org.openiam.provision.dto.srcadapter.SourceAdapterRequest;


public class SourceAdapterPreProcessorExecutor implements SourceAdapterPreProcessor{
    public int perform(SourceAdapterRequest request) throws Exception {

        Set<SourceAdapterOrganizationRequest> organizationRequests = request.getOrganizations()
        if (organizationRequests) {
            SourceAdapterOrganizationRequest organizationRequest = null;
            for (SourceAdapterOrganizationRequest o : organizationRequests) {
                organizationRequest = o;
                break;
            }
            if (organizationRequest) {
                String attributeRequest = organizationRequest.getEntityAttributes()?.find({
                    "GlobalOrgUnit Sub Business Unit Shortname".equals(it.getName())
                })?.value;
                Set<SourceAdapterAttributeRequest> userAttrs = request.getUserAttributes();
                if (!userAttrs) {
                    request.setUserAttributes(new HashSet<SourceAdapterAttributeRequest>());
                }
                userAttrs.add(new SourceAdapterAttributeRequest(name: "ORG_SBU_SHORT_NAME", value: attributeRequest));
            }
        }
        println("Source Adapter Pre processor SUCCESS");
        return 0;
    }
}

