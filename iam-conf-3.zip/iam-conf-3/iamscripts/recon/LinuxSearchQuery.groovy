output = "not user for Linux"
