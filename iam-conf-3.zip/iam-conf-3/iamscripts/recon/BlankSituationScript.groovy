import org.openiam.provision.dto.ProvisionUser

public class BlankSituationScript extends org.openiam.idm.srvc.recon.service.AbstractPopulationScript {
    public int execute(Map<String, String> line, ProvisionUser pUser){
        int retval = 1;
        return retval;
    }

}