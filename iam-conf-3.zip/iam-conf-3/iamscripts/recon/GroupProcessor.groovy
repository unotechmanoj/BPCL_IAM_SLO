import org.apache.commons.collections.CollectionUtils
import org.apache.commons.lang.StringUtils
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import org.openiam.base.id.UUIDGen
import org.openiam.base.ws.ResponseStatus
import org.openiam.connector.type.ObjectValue
import org.openiam.connector.type.constant.StatusCodeType
import org.openiam.connector.type.request.SearchRequest
import org.openiam.connector.type.response.SearchResponse
import org.openiam.exception.ScriptEngineException
import org.openiam.idm.searchbeans.GroupSearchBean
import org.openiam.idm.srvc.audit.constant.AuditAttributeName
import org.openiam.idm.srvc.audit.dto.IdmAuditLog
import org.openiam.idm.srvc.auth.dto.IdentityDto
import org.openiam.idm.srvc.auth.dto.IdentityTypeEnum
import org.openiam.idm.srvc.auth.login.IdentityService
import org.openiam.idm.srvc.grp.dto.Group
import org.openiam.idm.srvc.grp.ws.GroupDataWebService
import org.openiam.idm.srvc.key.constant.KeyName
import org.openiam.idm.srvc.key.service.KeyManagementService
import org.openiam.idm.srvc.mngsys.dto.*
import org.openiam.idm.srvc.mngsys.ws.ManagedSystemWebService
import org.openiam.idm.srvc.mngsys.ws.ProvisionConnectorWebService
import org.openiam.idm.srvc.recon.command.ReconciliationCommandFactory
import org.openiam.idm.srvc.recon.dto.ReconExecStatusOptions
import org.openiam.idm.srvc.recon.dto.ReconciliationConfig
import org.openiam.idm.srvc.recon.dto.ReconciliationResponse
import org.openiam.idm.srvc.recon.dto.ReconciliationSituation
import org.openiam.idm.srvc.recon.service.*
import org.openiam.idm.srvc.res.dto.Resource
import org.openiam.idm.srvc.res.service.ResourceDataService
import org.openiam.idm.srvc.synch.dto.Attribute
import org.openiam.idm.srvc.synch.service.MatchObjectRule
import org.openiam.idm.srvc.synch.srcadapter.MatchRuleFactory
import org.openiam.idm.srvc.user.dto.User
import org.openiam.idm.srvc.user.dto.UserStatusEnum
import org.openiam.idm.srvc.user.ws.UserDataWebService
import org.openiam.provision.dto.ProvisionGroup
import org.openiam.provision.resp.LookupObjectResponse
import org.openiam.provision.service.AbstractProvisioningService
import org.openiam.provision.service.ConnectorAdapter
import org.openiam.provision.service.ObjectProvisionService
import org.openiam.provision.service.ProvisionServiceUtil
import org.openiam.provision.type.ExtensibleAttribute
import org.openiam.provision.type.ExtensibleGroup
import org.openiam.script.ScriptIntegration
import org.openiam.util.encrypt.Cryptor
import org.springframework.context.ApplicationContext

public class GroupProcessor implements ReconciliationProcessor {

    protected ApplicationContext context;

    private static final Log log = LogFactory.getLog(ReconciliationProcessor.class);

    public GroupProcessor() {
    }

    public void setApplicationContext(ApplicationContext applicationContext) {
        this.context = applicationContext;
    }
    private ManagedSystemWebService managedSysWs
    private ResourceDataService resourceDataService
    private ProvisionConnectorWebService connectorService
    private ReconciliationConfigService configService
    private GroupDataWebService groupWS
    private KeyManagementService keyManagementService
    private Cryptor cryptor
    private ScriptIntegration scriptRunner
    private ConnectorAdapter connectorAdapter
    private MatchRuleFactory matchRuleFactory
    private ReconciliationCommandFactory commandFactory
    private IdentityService identityService
    private ObjectProvisionService provisionService
    private UserDataWebService userWS

    public ReconciliationResponse startReconciliation(
            final ReconciliationConfig config, final IdmAuditLog idmAuditLog) {

        /** *****************/
        managedSysWs = context.getBean("managedSysService") as ManagedSystemWebService
        resourceDataService = context.getBean("resourceDataService") as ResourceDataService
        connectorService = context.getBean("provisionConnectorWebService") as ProvisionConnectorWebService
        configService = context.getBean(ReconciliationConfigService.class);
        groupWS = context.getBean("groupWS") as GroupDataWebService
        keyManagementService = context.getBean("keyManagementService") as KeyManagementService
        cryptor = context.getBean("cryptor") as Cryptor
        scriptRunner = context.getBean("configurableGroovyScriptEngine") as ScriptIntegration
        connectorAdapter = context.getBean(ConnectorAdapter.class)
        matchRuleFactory = context.getBean("matchRuleFactory") as MatchRuleFactory
        commandFactory = context.getBean("reconciliationFactory") as ReconciliationCommandFactory
        identityService = context.getBean("identityManager") as IdentityService
        provisionService = context.getBean("groupProvision") as ObjectProvisionService
        userWS = context.getBean("userWS") as UserDataWebService
        /** **************/


        log.debug("Reconciliation started for configId=" + config.getReconConfigId() + " - resource="
                + config.getResourceId());

        Resource res = resourceDataService.getResource(config.getResourceId(), null);
        ManagedSysDto mSys = managedSysWs.getManagedSysByResource(res.getId());
        String managedSysId = (mSys != null) ? mSys.getId() : null;
        // have resource
        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION,
                "Reconciliation for target system: " + mSys.getName() + " is started..." + new Date());
        log.debug("ManagedSysId = " + managedSysId);
        log.debug("Getting identities for managedSys");

        if (mSys && mSys?.getPswd() != null) {
            try {
                final byte[] bytes = keyManagementService.getSystemUserKey(KeyName.password.name());
                mSys.setDecryptPassword(cryptor.decrypt(bytes, mSys.getPswd()));
            } catch (Exception e) {
                log.error("Can't decrypt", e);
            }
        }
        // have situations
//        Map<String, ReconciliationObjectCommand> situations = new HashMap<String, ReconciliationObjectCommand>();
        Map<String, ReconciliationSituation> situations = new HashMap<String, ReconciliationSituation>();
        for (ReconciliationSituation situation : config.getSituationSet()) {
//            situations.put(situation.getSituation().trim(),
//                    commandFactory.createGroupCommand(situation.getSituationResp(), situation, managedSysId));
            situations.put(situation.getSituation().trim(), situation);

            log.debug("Created Command for: " + situation.getSituation());
        }

        // have resource connector
        ProvisionConnectorDto connector = connectorService.getProvisionConnector(mSys.getConnectorId());
        List<AttributeMap> attrMap = managedSysWs.getResourceAttributeMaps(mSys.getResourceId())
        // initialization match parameters of connector
        List<ManagedSystemObjectMatch> matchObjAry = managedSysWs.managedSysObjectParam(managedSysId, "GROUP")
        // execute all Reconciliation Commands need to be check
        if (CollectionUtils.isEmpty(matchObjAry)) {
            log.error("No match object found for this managed sys");
            return new ReconciliationResponse(ResponseStatus.FAILURE);
        }
        String keyField = matchObjAry.get(0).getKeyField();
        String baseDnField = matchObjAry.get(0).getBaseDn();

        GroupSearchBean groupSearchBean;
        if (StringUtils.isNotBlank(config.getMatchScript())) {
            Map<String, Object> bindingMap = new HashMap<String, Object>();
            bindingMap.put(AbstractProvisioningService.TARGET_SYS_MANAGED_SYS_ID, mSys.getId());
            bindingMap.put("searchFilter", config.getSearchFilter());
            bindingMap.put("updatedSince", config.getUpdatedSince());
            IDMSearchScript searchScript = (IDMSearchScript) scriptRunner.instantiateClass(bindingMap,
                    config.getMatchScript());
            groupSearchBean = searchScript.createGroupSearchBean(bindingMap);
        } else {
            groupSearchBean = new GroupSearchBean();
        }

// checking for STOP status
        ReconciliationConfig reconConfig = configService.getConfigById(config.getReconConfigId())
//        reconConfigDao.refresh(configEntity);
        checkIfStopped(reconConfig, idmAuditLog)

        // First get All Groups by search bean from IDM for processing
        List<String> processedGroupIds = new ArrayList<String>();

        if (groupSearchBean != null) {
            groupSearchBean.setManagedSysId(mSys.getId());
            List<Group> idmGroups = groupWS.findBeans(groupSearchBean, "3000", 0, Integer.MAX_VALUE)
            idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION, "Starting processing '" + idmGroups?.size()
                    + "' groups from Repository to " + mSys.getName());
            int counter = 0;
            for (Group group : idmGroups) {
                counter++;
                // checking for STOPING status for every 10 users
                if (counter == 10) {
                    checkIfStopped(reconConfig, idmAuditLog)

                    counter = 0;
                }
                processedGroupIds.add(group.getId());
                // IDs to avoid
                // double
                // processing
                idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION, "starting reconciliation for group: "
                        + group.getName());

                reconciliationIDMGroupToTargetSys(attrMap, group, mSys, situations,
                        config.getManualReconciliationFlag(), idmAuditLog);

                idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION, "finished reconciliation for user: "
                        + group.getName());
            }
        }

        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION,
                "Reconciliation from Repository to target system: " + mSys.getName() + " is complete.");

        // 2. Do reconciliation users from Target Managed System to IDM
        // search for all Roles and Groups related with resource
        // GET Users from ConnectorAdapter by BaseDN and query rules

        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION,
                "Starting processing from target system: " + mSys.getName() + " to Repository");

        // checking for STOPPING status
        checkIfStopped(reconConfig, idmAuditLog)


        processingTargetToIDM(config, managedSysId, mSys, situations, connector, keyField, baseDnField,
                processedGroupIds, idmAuditLog);

        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION,
                "Reconciliation from target system: " + mSys.getName() + " to Repository is complete.");

        reconConfig.setLastExecTime(new Date());
        reconConfig.setExecStatus(ReconExecStatusOptions.FINISHED);

        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION,
                "Reconciliation for target system: " + mSys.getName() + " is complete.");

        return new ReconciliationResponse(ResponseStatus.SUCCESS);
    };

    private static checkIfStopped(ReconciliationConfig reconConfig, IdmAuditLog idmAuditLog) {
        if (reconConfig.getExecStatus() == ReconExecStatusOptions.STOPPING) {
            reconConfig.setExecStatus(ReconExecStatusOptions.STOPPED);
            idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION, "Reconciliation was manually stopped at "
                    + new Date());
            return new ReconciliationResponse(ResponseStatus.SUCCESS);
        }
    }

    private ReconciliationResponse processingTargetToIDM(ReconciliationConfig config, String managedSysId,
                                                         ManagedSysDto mSys,
                                                         Map<String, ReconciliationSituation> situations,
                                                         ProvisionConnectorDto connector,
                                                         String keyField,
                                                         String baseDnField,
                                                         List<String> processedGroupIds,
                                                         final IdmAuditLog idmAuditLog)
            throws ScriptEngineException {

        if (config == null) {
            log.error("Reconciliation config is null");
            return new ReconciliationResponse(ResponseStatus.FAILURE);
        }
        if (StringUtils.isBlank(config.getTargetSystemMatchScript())) {
            log.error("SearchQuery is not defined for reconciliation config.");
            return new ReconciliationResponse(ResponseStatus.FAILURE);
        }

        Map<String, Object> bindingMap = new HashMap<String, Object>();
        bindingMap.put(AbstractProvisioningService.TARGET_SYS_MANAGED_SYS_ID, mSys.getId());
        bindingMap.put("baseDnField", baseDnField);
        bindingMap.put("searchFilter", config.getTargetSystemSearchFilter());
        bindingMap.put("lastExecTime", config.getLastExecTime());
        bindingMap.put("updatedSince", config.getUpdatedSince());
        String searchQuery = (String) scriptRunner.execute(bindingMap, config.getTargetSystemMatchScript());
        if (StringUtils.isEmpty(searchQuery)) {
            log.error("SearchQuery not defined for this reconciliation config.");
            return new ReconciliationResponse(ResponseStatus.FAILURE);
        }
        log.debug("processingTargetToIDM: mSys=" + mSys);
        SearchRequest searchRequest = new SearchRequest();
        String requestId = "R" + UUIDGen.getUUID();
        searchRequest.setRequestID(requestId);
        searchRequest.setBaseDN(baseDnField);
        searchRequest.setScriptHandler(mSys.getSearchHandler());
        searchRequest.setSearchValue(keyField);
        searchRequest.setSearchQuery(searchQuery);
        searchRequest.setTargetID(managedSysId);
        searchRequest.setHostUrl(mSys.getHostUrl());
        searchRequest.setHostPort((mSys.getPort() != null) ? mSys.getPort().toString() : null);
        searchRequest.setHostLoginId(mSys.getUserId());
        searchRequest.setHostLoginPassword(mSys.getDecryptPassword());
        searchRequest.setExtensibleObject(new ExtensibleGroup());
        SearchResponse searchResponse;

        log.debug("Calling reconcileResource with Local connector");
        searchResponse = connectorAdapter.search(searchRequest, connector);

        if (searchResponse != null && searchResponse.getStatus() == StatusCodeType.SUCCESS) {
            List<ObjectValue> groupsFromRemoteSys = searchResponse.getObjectList();
            if (groupsFromRemoteSys != null) {

                // AUDITLOG COUNT of proccessing users from target sys
                int counter = 0;
                for (ObjectValue groupValue : groupsFromRemoteSys) {
                    counter++;
                    // AUDITLOG start processing user Y from target systems to
                    // IDM

                    // checking for STOPPING status every 10 users
                    if (counter == 10) {
                        checkIfStopped(config, idmAuditLog)
                        counter = 0;
                    }

                    List<ExtensibleAttribute> extensibleAttributes = groupValue.getAttributeList() != null ? groupValue
                            .getAttributeList() : new LinkedList<ExtensibleAttribute>();

                    String targetUserPrincipal = reconcilationTargetGroupObjectToIDM(managedSysId, mSys, situations,
                            extensibleAttributes, config, processedGroupIds, idmAuditLog);

                    if (StringUtils.isNotEmpty(targetUserPrincipal)) {
                        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION, "reconciled group: "
                                + targetUserPrincipal);
                    } else {
                        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION,
                                "reconciled group: " + groupValue.getObjectIdentity());
                    }
                }
            }
        } else {
            log.debug(searchResponse.getErrorMessage());
            idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION, "Error: " + searchResponse);
        }
        return new ReconciliationResponse(ResponseStatus.SUCCESS);
    }

    private boolean reconciliationIDMGroupToTargetSys(List<AttributeMap> attrMap,
                                                      final Group group,
                                                      final ManagedSysDto mSys,
                                                      final Map<String, ReconciliationSituation> situations,
                                                      boolean isManualRecon,
                                                      IdmAuditLog idmAuditLog) {

        IdentityDto identity = identityService.getIdentity(group.getId());

        log.debug("1 Reconciliation for group " + group);

        List<ExtensibleAttribute> requestedExtensibleAttributes = new ArrayList<ExtensibleAttribute>();

        for (AttributeMap ame : attrMap) {
            if ("GROUP".equalsIgnoreCase(ame.getMapForObjectType()) && "ACTIVE".equalsIgnoreCase(ame.getStatus())) {
                requestedExtensibleAttributes.add(new ExtensibleAttribute(ame.getAttributeName(), null));
            }
        }

        String principal = identity.getIdentity();
        log.debug("looking up identity in resource: " + principal);
        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION, "looking up identity in resource: " + principal);

        LookupObjectResponse lookupResp = provisionService.getTargetSystemObject(principal, mSys.getId(),
                requestedExtensibleAttributes);

        log.debug("Lookup status for " + principal + " =" + lookupResp.getStatus());
        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION,
                "Lookup status for " + principal + " =" + lookupResp.getStatus());
        //++v3.5
	if (!ResponseStatus.SUCCESS.equals(lookupResp.getStatus())) {
            if (ResponseCode.DIRECTORY_ERROR.equals(lookupResp.getErrorCode())) {
                log.error("Connection with Target system is down.");
                return false;
            }
        }
	//--v3.5

        boolean userFoundInTargetSystem = lookupResp.getStatus() == ResponseStatus.SUCCESS;
        ExtensibleGroup fromIDM = new ExtensibleGroup();
        ExtensibleGroup fromTS = new ExtensibleGroup();

        List<ExtensibleAttribute> extensibleAttributes = lookupResp.getAttrList() != null ? lookupResp.getAttrList()
                : new LinkedList<ExtensibleAttribute>();
        fromTS.setAttributes(extensibleAttributes);
        fromTS.setPrincipalFieldName(lookupResp.getPrincipalName());
        fromIDM.setAttributes(new ArrayList<ExtensibleAttribute>());
        this.getValuesForExtensibleGroup(fromIDM, group, attrMap, identity);
        if (userFoundInTargetSystem) {
            // Record exists in resource
            if (UserStatusEnum.DELETED.getValue().equalsIgnoreCase(group.getStatus())) {
                // IDM_DELETED__SYS_EXISTS
                if (!isManualRecon) {
//                    ReconciliationObjectCommand<ProvisionGroup> command = situations.get(ReconciliationCommand.IDM_DELETED__SYS_EXISTS);
                    ReconciliationSituation situation = situations.get(ReconciliationCommand.IDM_DELETED__SYS_EXISTS);
                    ReconciliationObjectCommand<Group> command = commandFactory.createGroupCommand(situation.getSituationResp(), situation, mSys.getId());
                    if (command != null) {
                        log.debug("Call command for: Record in resource but deleted in IDM");
                        ProvisionGroup provisionGroup = new ProvisionGroup(group);
                        provisionGroup.setParentAuditLogId(idmAuditLog.getId());
                        provisionGroup.setSrcSystemId(mSys.getId());
                        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION,
                                "SYS_EXISTS__IDM_NOT_EXISTS for group= " + principal);

                         command.execute(situation, identity.getIdentity(), mSys.getId(), provisionGroup, extensibleAttributes);




                    }
                }
            } else {
                // IDM_EXISTS__SYS_EXISTS

                if (!isManualRecon) {
                     ReconciliationSituation situation = situations.get(ReconciliationCommand.IDM_EXISTS__SYS_EXISTS);
                    ReconciliationObjectCommand<Group> command = commandFactory.createGroupCommand(situation.getSituationResp(), situation, mSys.getId());
                    if (command != null) {
                        log.debug("Call command for: Record in resource and in IDM");
                        ProvisionGroup provisionGroup = new ProvisionGroup(group);
                        provisionGroup.setParentAuditLogId(idmAuditLog.getId());
                        provisionGroup.setSrcSystemId(mSys.getId());

                        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION, "IDM_EXISTS__SYS_EXISTS for group= "
                                + principal);

                        command.execute(situation, identity.getIdentity(), mSys.getId(), provisionGroup, extensibleAttributes);
                    }
                }
            }

        } else {
            // Record not found in resource
            if (!UserStatusEnum.DELETED.getValue().equalsIgnoreCase(group.getStatus())) {
                // IDM_EXISTS__SYS_NOT_EXISTS
                if (!isManualRecon) {

                    ReconciliationSituation situation = situations.get(ReconciliationCommand.IDM_EXISTS__SYS_NOT_EXISTS);
                    ReconciliationObjectCommand<Group> command = commandFactory.createGroupCommand(situation.getSituationResp(), situation, mSys.getId());
                    if (command != null) {
                        log.debug("Call command for: Record in resource and in IDM");
                        ProvisionGroup provisionGroup = new ProvisionGroup(group);
                        provisionGroup.setParentAuditLogId(idmAuditLog.getId());
                        provisionGroup.setSrcSystemId(mSys.getId());

                        idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION,
                                "IDM_EXISTS__SYS_NOT_EXISTS for group= " + principal);

                        command.execute(situation, identity.getIdentity(), mSys.getId(), provisionGroup, extensibleAttributes);
                    }
                }
            }
        }

        return true;
    }

    private void getValuesForExtensibleGroup(ExtensibleGroup fromIDM, Group group, List<AttributeMap> attrMap,
                                             IdentityDto identity) {
        Map<String, Object> bindingMap = new HashMap<String, Object>();
        try {
            bindingMap.put("group", new ProvisionGroup(group));
            bindingMap.put("managedSysId", identity.getManagedSysId());
            final List<ManagedSystemObjectMatch> matchList = managedSysWs.managedSysObjectParam(identity.managedSysId, "GROUP")
            if (CollectionUtils.isNotEmpty(matchList)) {
                bindingMap.put("matchParam", matchList);
            }
            // get all users for group
            List<User> curUserList = userWS.getUsersForGroup(group.getId(), "3000", -1, -1)
//            String decPassword = "";
            if (identity != null) {
                if (StringUtils.isEmpty(identity.getReferredObjectId())) {
                    throw new IllegalArgumentException("Identity userId can not be empty");
                }

                bindingMap.put("identity", identity);
                bindingMap.put("targetSystemIdentity", identity.getIdentity());
            }

            // make the role and group list before these updates available to
            // the
            // attribute policies
            bindingMap.put("currentUserList", curUserList);
            for (AttributeMap attr : attrMap) {
                fromIDM.getAttributes().add(
                        new ExtensibleAttribute(attr.getAttributeName(), (String) ProvisionServiceUtil
                                .getOutputFromAttrMap(attr, bindingMap, scriptRunner)));
                if (PolicyMapObjectTypeOptions.GROUP_PRINCIPAL.name().equalsIgnoreCase(attr.getMapForObjectType())
                        && !"INACTIVE".equalsIgnoreCase(attr.getStatus())) {
                    fromIDM.setPrincipalFieldName(attr.getAttributeName());
                }
            }

        } catch (Exception e) {
            log.error(e);
            e.printStackTrace();
        }
    }

    // Reconciliation processingTargetToIDM
    private String reconcilationTargetGroupObjectToIDM(String managedSysId, ManagedSysDto mSys,
                                                       Map<String, ReconciliationSituation> situations,
                                                       List<ExtensibleAttribute> extensibleAttributes,
                                                       ReconciliationConfig config,
                                                       List<String> processedGroupIds,
                                                       final IdmAuditLog idmAuditLog) {
        String targetGroupPrincipal = null;
        Map<String, Attribute> attributeMap = new HashMap<String, Attribute>();
        for (ExtensibleAttribute attr : extensibleAttributes) {
            // search principal attribute by KeyField
            attributeMap.put(attr.getName(), attr);
            if (attr.getName().equals(config.getCustomMatchAttr())) {
                targetGroupPrincipal = attr.getValue();
                break;
            }
        }

        if (StringUtils.isBlank(targetGroupPrincipal)) {
            throw new IllegalArgumentException("Target system Principal can not be defined with Match Attribute Name: "
                    + config.getCustomMatchAttr());
        }

        try {
            MatchObjectRule matchObjectRule = matchRuleFactory.create(config.getCustomIdentityMatchScript());
            Group grp = matchObjectRule.lookupGroup(config, attributeMap);

            if (grp != null) {
                if (processedGroupIds.contains(grp.getId())) { // already
                    // processed
                    return targetGroupPrincipal;
                }
                Group gr = groupWS.getGroup(grp.getId(), null)
                //TODO check the identity with groupIdentity
                IdentityDto identityDto = identityService.getIdentity(gr.getId());
                // situation TARGET EXIST, IDM EXIST do modify
                // if user exists but don;t have principal for current target
                // sys
//                ReconciliationObjectCommand command = situations.get(ReconciliationCommand.IDM_EXISTS__SYS_EXISTS);
                ReconciliationSituation situation = situations.get(ReconciliationCommand.IDM_EXISTS__SYS_EXISTS);
                ReconciliationObjectCommand<Group> command = commandFactory.createGroupCommand(situation.getSituationResp(), situation, mSys.getId());
                if (command != null) {
                    ProvisionGroup newGroup = new ProvisionGroup(gr);
                    newGroup.setSrcSystemId(managedSysId);

                    log.debug("Call command for IDM Match Found");
                    idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION, "IDM_EXISTS__SYS_EXISTS for group= "
                            + identityDto.identity);

                    // AUDIT LOG Y user processing IDM_EXISTS__SYS_EXISTS
                    // situation
                    command.execute(situation, identityDto.getIdentity(), mSys.getId(), newGroup, extensibleAttributes);

                }
            } else {
                // create new user in IDM
//                ReconciliationObjectCommand command = situations.get(ReconciliationCommand.SYS_EXISTS__IDM_NOT_EXISTS);
                ReconciliationSituation situation = situations.get(ReconciliationCommand.SYS_EXISTS__IDM_NOT_EXISTS);
                ReconciliationObjectCommand<Group> command = commandFactory.createGroupCommand(situation.getSituationResp(), situation, mSys.getId());
                if (command != null) {
                    ProvisionGroup newGroup = new ProvisionGroup();

                    newGroup.setSrcSystemId(managedSysId);
                    newGroup.setMdTypeId("GENERAL_GROUP");

                    IdentityDto identityDto = new IdentityDto(IdentityTypeEnum.GROUP, managedSysId, targetGroupPrincipal, newGroup.getId());
                    log.debug("Call command for Match Not Found");
                    idmAuditLog.addAttribute(AuditAttributeName.DESCRIPTION, "SYS_EXISTS__IDM_NOT_EXISTS for group= "
                            + targetGroupPrincipal);

                    // AUDIT LOG Y user processing SYS_EXISTS__IDM_NOT_EXISTS
                    // situation
                     command.execute(situation, identityDto.getIdentity(), mSys.getId(), newGroup, extensibleAttributes);
                }
            }

        } catch (ClassNotFoundException cnfe) {
            log.error(cnfe);
        }
        return targetGroupPrincipal;
    }
}
