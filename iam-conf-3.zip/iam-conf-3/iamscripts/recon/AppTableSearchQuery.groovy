output = "*"
