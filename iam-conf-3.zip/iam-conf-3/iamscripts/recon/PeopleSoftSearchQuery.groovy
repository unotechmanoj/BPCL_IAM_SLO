output = "WHERE OPRID LIKE '%'"
