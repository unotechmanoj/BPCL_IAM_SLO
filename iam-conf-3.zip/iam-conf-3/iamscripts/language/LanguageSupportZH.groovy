
import org.openiam.ui.util.LanguageSupport;


public class LanguageSupportZH implements LanguageSupport   {

	public String addArticle(String word) {
		System.out.println("LanguageSupportZH script called with 'addArticle' command");
		return "";
	}

}
