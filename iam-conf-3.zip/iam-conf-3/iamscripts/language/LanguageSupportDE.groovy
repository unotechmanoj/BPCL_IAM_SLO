
import org.openiam.ui.util.LanguageSupport;


public class LanguageSupportDE implements LanguageSupport   {

	public String addArticle(String word) {
		System.out.println("LanguageSupportDE script called with 'addArticle' command");
		return "";
	}

}
