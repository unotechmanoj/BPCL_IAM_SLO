
import org.openiam.ui.util.LanguageSupport;


public class LanguageSupportES implements LanguageSupport   {

	public String addArticle(String word) {
		System.out.println("LanguageSupportES script called with 'addArticle' command");
		return "";
	}

}
