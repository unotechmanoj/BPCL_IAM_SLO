
import org.openiam.ui.util.LanguageSupport;


public class LanguageSupportJA implements LanguageSupport   {

	public String addArticle(String word) {
		System.out.println("LanguageSupportJA script called with 'addArticle' command");
		return "";
	}

}
