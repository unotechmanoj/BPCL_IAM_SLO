
import org.openiam.ui.util.LanguageSupport;


public class LanguageSupportRU implements LanguageSupport   {

	public String addArticle(String word) {
		System.out.println("LanguageSupportRU script called with 'addArticle' command");
		return "";
	}

}
