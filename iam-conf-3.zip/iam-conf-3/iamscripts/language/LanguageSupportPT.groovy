
import org.openiam.ui.util.LanguageSupport;


public class LanguageSupportPT implements LanguageSupport   {

	public String addArticle(String word) {
		System.out.println("LanguageSupportPT script called with 'addArticle' command");
		return "";
	}

}
