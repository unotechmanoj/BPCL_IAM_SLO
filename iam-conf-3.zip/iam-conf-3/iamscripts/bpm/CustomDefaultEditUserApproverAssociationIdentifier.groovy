package bpm

import org.openiam.bpm.activiti.groovy.DefaultEditUserApproverAssociationIdentifier;

class CustomDefaultEditUserApproverAssociationIdentifier extends DefaultEditUserApproverAssociationIdentifier {

	@Override
	public void calculateApprovers() {
		super.calculateApprovers();
	}
	
}
