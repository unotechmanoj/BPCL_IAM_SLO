import org.openiam.idm.srvc.user.dto.UserStatusEnum

if ( UserStatusEnum.ACTIVE== user.status){
output="A"
}else{
output="N"
}
