// for Powershell-AD connector use full path: output = 'ou=test' + ',' + matchParam.baseDn
output = null
