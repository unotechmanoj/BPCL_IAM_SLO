// for Active Direcory connector use relative path: output = 'ou=test'
output = null
