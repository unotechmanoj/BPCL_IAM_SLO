import org.openiam.idm.srvc.user.dto.UserStatusEnum

if (user.status == UserStatusEnum.ACTIVE){
    output="True"
} else {
    output="False"
}