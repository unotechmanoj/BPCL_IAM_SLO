output = user.firstName + ' ' + user.lastName
