
List<String> objectClassList = new ArrayList<String>();

objectClassList.add("top");
objectClassList.add("person");
objectClassList.add("organizationalPerson");
objectClassList.add("inetOrgPerson");

output=objectClassList;

