
if (user.employeeId != null && user.employeeId.length() > 0) {
output=user.employeeId
}else {
output = null
}

