import org.openiam.idm.searchbeans.EmailSearchBean
import org.openiam.idm.srvc.user.ws.UserDataWebService
import org.openiam.provision.dto.ProvisionUser
import org.openiam.base.AttributeOperationEnum

output = getPrimaryEmail(user)
if (output) {
    return
}


private String getPrimaryEmail(ProvisionUser user) {
println("get user emailAddresses :" + user.emailAddresses)
    def email = user.emailAddresses.find({
        it.metadataTypeId == 'PRIMARY_EMAIL' &&
        it.operation != AttributeOperationEnum.DELETE
    })?.emailAddress

    if (!email) {
        def userWS = context.getBean('userWS') as UserDataWebService
        def searchBean = new EmailSearchBean(metadataTypeId: 'PRIMARY_EMAIL', parentId: user.id)
        def emails = userWS.findEmailBeans(searchBean, 1, 0)
        email = emails ? emails.get(0)?.emailAddress : null
    }
    return email
}
