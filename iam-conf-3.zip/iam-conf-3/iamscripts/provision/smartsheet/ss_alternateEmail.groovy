import org.openiam.idm.searchbeans.EmailSearchBean
import org.openiam.idm.srvc.user.ws.UserDataWebService
import org.openiam.provision.dto.ProvisionUser
import org.openiam.base.AttributeOperationEnum

// split emails by ";"
// we can't add alternateEmails while user.status != ACTIVE

output = getEmails(user)
if (output) {
    return
}


private String getEmails(ProvisionUser user) {
    def email = '';
    def emm = user.emailAddresses.findAll({
        it.metadataTypeId != 'PRIMARY_EMAIL' &&
        it.operation != AttributeOperationEnum.DELETE
    });
emm.each{v -> email = email + (email?';':'') + v?.emailAddress};
    return email
}
