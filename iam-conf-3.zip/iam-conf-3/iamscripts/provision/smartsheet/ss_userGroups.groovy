import org.openiam.base.AttributeOperationEnum
import org.openiam.base.BaseAttribute
import org.openiam.base.BaseAttributeContainer
import org.openiam.idm.srvc.grp.dto.Group
import org.openiam.idm.srvc.auth.login.IdentityService
import org.openiam.idm.srvc.auth.dto.IdentityDto;

output = null
def attributeContainer = new BaseAttributeContainer()

IdentityService identityManager = context.getBean('identityManager')
user.groups?.each{Group g->
    if (g.operation == AttributeOperationEnum.ADD || g.operation == AttributeOperationEnum.DELETE) {
        def groupIdentity = identityManager.getIdentityByManagedSys(g.id, managedSysId)
        attributeContainer.attributeList.add(new BaseAttribute(groupIdentity.getIdentity(), g.name, g.operation))
    }
}
if (attributeContainer.attributeList) {
    output = attributeContainer
}

