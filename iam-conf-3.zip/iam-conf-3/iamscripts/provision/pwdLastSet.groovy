import org.openiam.idm.srvc.auth.dto.Login
import org.openiam.idm.srvc.pswd.service.PasswordService

output = "RESET_PASSWORD".equals(binding.getVariable("operation")) && changePasswordOnReset ? "0" : null
println "===== pwdLastSet.groovy, output: " + output

// use actual password policy to determine if AD flag "change password on next logon" should be set
private boolean getChangePasswordOnReset() {
    def passwordManager = context.getBean("passwordManager") as PasswordService
    if (binding.hasVariable('lg')) {
        def login = binding.getVariable('lg') as Login
        def policy = passwordManager.getPasswordPolicy(login.login, login.managedSysId)
        String value = policy.getAttribute('CHNG_PSWD_ON_RESET')?.value1
        return value && "true".equalsIgnoreCase(value)
    }
    return false
}