
output = user?.getAttribute("EMAIL_ALIASES")?.value
