output =  user.roles?: attributeDefaultValue
