
if (lg.login) {
	output = lg.login
} else {
	output = user.firstName + "." + user.lastName
}
