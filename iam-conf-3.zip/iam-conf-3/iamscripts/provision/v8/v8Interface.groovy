output = user.groups?: attributeDefaultValue
