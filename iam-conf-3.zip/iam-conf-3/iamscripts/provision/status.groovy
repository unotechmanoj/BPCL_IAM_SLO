import org.openiam.idm.srvc.user.dto.UserStatusEnum

if (user.status == UserStatusEnum.ACTIVE){
output="Active"
}else{
output="Inactive"
}
