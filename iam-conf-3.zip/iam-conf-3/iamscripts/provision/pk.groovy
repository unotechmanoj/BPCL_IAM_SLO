loginID=lg.login


output = loginID