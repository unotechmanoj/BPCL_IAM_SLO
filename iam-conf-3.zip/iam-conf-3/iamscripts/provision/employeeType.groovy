if (user.employeeTypeId != null && user.employeeTypeId.length() > 0) {
output=user.employeeTypeId
}else {
output = null
}


