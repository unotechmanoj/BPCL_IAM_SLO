/*
group - New group object that has been submitted to the provisioning service
*/

output=identity?.identity