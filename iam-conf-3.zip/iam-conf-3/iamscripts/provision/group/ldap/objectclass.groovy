
output = ['top', 'groupOfUniqueNames']

