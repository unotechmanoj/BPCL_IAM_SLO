println("================ cn.groovy starting..");
output=identity?.identity
println("================ cn.groovy output="+output);