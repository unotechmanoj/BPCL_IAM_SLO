output = group.description
