if (user.addresses != null &&  user.addresses.size()  > 0) {
    output= user.addresses.state
}else {
    output=null;
}
