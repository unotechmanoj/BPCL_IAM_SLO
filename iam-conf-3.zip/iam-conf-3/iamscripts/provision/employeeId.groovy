import org.openiam.base.BaseConstants

output = (user.employeeId&&(user.employeeId!=BaseConstants.NULL_STRING))? user.employeeId: null