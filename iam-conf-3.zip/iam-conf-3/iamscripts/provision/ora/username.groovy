output = lg.login?.toUpperCase() ?: null
