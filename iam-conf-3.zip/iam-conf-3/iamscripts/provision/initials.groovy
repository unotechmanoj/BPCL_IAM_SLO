


if (user.firstName != null && user.lastName != null) {
  output =user.firstName.substring(0,1) + user.lastName.substring(0,1) 
}else {
	output=""
}

