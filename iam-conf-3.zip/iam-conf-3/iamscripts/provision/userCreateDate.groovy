output = null

if (user.createDate) {
    output = user.createDate
}
