USE openiam;

UPDATE IDENTITY_QUESTION SET QUESTION_TEXT='Where did you meet your significant other?' WHERE IDENTITY_QUESTION_ID=217;
